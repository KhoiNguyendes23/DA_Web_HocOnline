﻿using System.Collections.Generic;

namespace Do_An_Web_Hoc.Models
{
    public class CourseDetailViewModel
    {
        public Courses Course { get; set; }
        public List<Lectures> Lectures { get; set; }
    }
}

﻿namespace Do_An_Web_Hoc.Models
{
    public class RevenueStatisticViewModel
    {
        public int Month { get; set; }
        public int Year { get; set; }
        public int TotalEnrollments { get; set; }
        public decimal TotalRevenue { get; set; }
    }
}

﻿namespace Do_An_Web_Hoc.Models
{
    public class MomoPaymentRequest
    {
    }
}

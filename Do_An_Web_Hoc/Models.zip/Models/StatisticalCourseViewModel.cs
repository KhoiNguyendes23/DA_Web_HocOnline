﻿namespace Do_An_Web_Hoc.Models
{
    public class StatisticalCourseViewModel
    {
        public string CourseName { get; set; }
        public int EnrollmentCount { get; set; }
    }
}

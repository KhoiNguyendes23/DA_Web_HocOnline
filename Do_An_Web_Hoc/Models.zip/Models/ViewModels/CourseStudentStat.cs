﻿namespace Do_An_Web_Hoc.Models.ViewModels
{
    public class CourseStudentStat
    {
        public string CourseName { get; set; }
        public int StudentCount { get; set; }
    }
}

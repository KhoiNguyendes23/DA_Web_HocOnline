﻿namespace Do_An_Web_Hoc.Models.ViewModels
{
    public class TopCourseViewModel
    {
        public string CourseName { get; set; }
        public int EnrollmentCount { get; set; }
    }
}

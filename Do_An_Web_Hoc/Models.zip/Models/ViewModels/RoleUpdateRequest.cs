﻿namespace Do_An_Web_Hoc.Models.ViewModels
{
    public class RoleUpdateRequest
    {
        public int UserId { get; set; }
        public int NewRoleId { get; set; }
    }

}

﻿namespace Do_An_Web_Hoc.Models.ViewModels
{
    public class RankingViewModel
    {
        public int UserID { get; set; }
        public string FullName { get; set; }
        public int TotalScore { get; set; }
        public int QuizCount { get; set; }
    }
}

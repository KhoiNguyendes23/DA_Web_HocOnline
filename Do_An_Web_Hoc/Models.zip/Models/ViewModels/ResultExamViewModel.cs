﻿namespace Do_An_Web_Hoc.Models.ViewModels
{
    public class ResultExamViewModel
    {
        public string StudentName { get; set; }
        public string ExamName { get; set; }
        public string QuizName { get; set; }
        public float? Score { get; set; }
        public DateTime? SubmissionTime { get; set; }
    }
}

﻿namespace Do_An_Web_Hoc.Models.ViewModels
{
    public class UserRoleViewModel
    {
        public int UserID { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public int? RoleID { get; set; }
        public string RoleName { get; set; }
    }

}

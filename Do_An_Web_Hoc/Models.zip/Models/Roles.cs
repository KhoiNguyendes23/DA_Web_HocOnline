﻿using System.ComponentModel.DataAnnotations;

namespace Do_An_Web_Hoc.Models
{
    public class Roles
    {
        [Key]
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}

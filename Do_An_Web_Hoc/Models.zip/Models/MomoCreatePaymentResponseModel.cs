﻿namespace Do_An_Web_Hoc.Models
{
    public class MomoCreatePaymentResponseModel
    {
        public string PayUrl { get; set; }
        public int ErrorCode { get; set; }
        public string Message { get; set; }
    }
}
